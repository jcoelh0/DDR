% media do tempo de permanencia 1/qi
% qi � a taxa � qual o processo faz uma transi��o quando est� no estado i

t0 = (1/1)*60
t1 = (1/(195+5))*60
t2 = (1/(40+10))*60
t3 = (1/(20+10))*60
t4 = (1/5)*60